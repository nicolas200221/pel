#include "trie.hpp"  // It is forbidden to include other libraries!

/* Here below, your implementation of trie. */